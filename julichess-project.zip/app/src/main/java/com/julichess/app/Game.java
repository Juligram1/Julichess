package com.julichess.app;

import java.util.ArrayList;

/** One game: rules, clocks, offers, pause, disconnect claims and PGN. Time is passed in, never read. */
public final class Game {
    public static final long CLAIM_AFTER_MS = 60_000;

    public final String id;
    public final int number;
    public final String[] pid = new String[2];
    public final String[] pname = new String[2];
    public final long baseMs, incMs;
    public final Chess pos = Chess.start();
    public final ArrayList<String> san = new ArrayList<>();
    public final ArrayList<Integer> moves = new ArrayList<>();
    public final ArrayList<long[]> clkAfter = new ArrayList<>();

    private final long[] clock = new long[2];
    private long lastTick;

    public boolean started = false;   // clocks run after White's first move
    public boolean paused = false;
    public boolean over = false;
    public String result = "*";
    public String reason = "";
    public int drawOfferBy = -1;
    public int takebackBy = -1;
    public int lastMove = -1;
    public final long[] offlineSince = new long[2]; // 0 = online
    public final boolean[] claimNotified = new boolean[2];
    public boolean reported = false;

    public Game(String id, int number, String whiteId, String whiteName, String blackId, String blackName, long baseMs, long incMs) {
        this.id = id; this.number = number;
        pid[0] = whiteId; pname[0] = whiteName; pid[1] = blackId; pname[1] = blackName;
        this.baseMs = baseMs; this.incMs = incMs;
        clock[0] = baseMs; clock[1] = baseMs;
    }

    public long remaining(int side, long now) {
        if (started && !over && !paused && pos.side == side) return Math.max(0, clock[side] - (now - lastTick));
        return clock[side];
    }

    /** Ends the game on time if the side to move has run out. Returns true when the game just ended. */
    public boolean tick(long now) {
        if (over || paused || !started) return false;
        int s = pos.side;
        if (clock[s] - (now - lastTick) > 0) return false;
        clock[s] = 0;
        int other = 1 - s;
        if (pos.hasMatingMaterial(other)) end(other == 0 ? "1-0" : "0-1", "time forfeit");
        else end("1/2-1/2", "time out, no mating material");
        return true;
    }

    private void end(String res, String why) {
        over = true; result = res; reason = why;
        drawOfferBy = -1; takebackBy = -1;
    }

    public String move(int side, int from, int to, int promo, long now) {
        if (over) return "The game is over.";
        if (paused) return "The game is paused.";
        if (pos.side != side) return "It is not your turn.";
        if (tick(now)) return "Your time ran out.";
        int m = pos.find(from, to, promo);
        if (m < 0) return "That move is not legal.";
        if (started) {
            clock[side] -= now - lastTick;
            if (clock[side] < 0) clock[side] = 0;
        }
        san.add(pos.san(m));
        pos.play(m);
        moves.add(m);
        lastMove = m;
        if (!started) started = true;      // first move: no time spent, no increment
        else clock[side] += incMs;
        lastTick = now;
        clkAfter.add(new long[]{clock[0], clock[1]});
        drawOfferBy = -1; takebackBy = -1;
        String st = pos.status();
        if (st != null) {
            switch (st) {
                case "checkmate": end(side == 0 ? "1-0" : "0-1", "checkmate"); break;
                case "stalemate": end("1/2-1/2", "stalemate"); break;
                case "insufficient": end("1/2-1/2", "insufficient material"); break;
                case "fifty": end("1/2-1/2", "fifty-move rule"); break;
                default: end("1/2-1/2", "threefold repetition"); break;
            }
        }
        return null;
    }

    public String resign(int side) {
        if (over) return "The game is over.";
        end(side == 0 ? "0-1" : "1-0", "resignation");
        return null;
    }

    public String abort() {
        if (over) return "The game is over.";
        end("*", "ended by the host");
        return null;
    }

    public String offerDraw(int side) {
        if (over) return "The game is over.";
        if (drawOfferBy == side) return "You already offered a draw.";
        if (drawOfferBy == 1 - side) { end("1/2-1/2", "draw agreed"); return null; }
        drawOfferBy = side;
        return null;
    }

    public String respondDraw(int side, boolean accept) {
        if (over || drawOfferBy != 1 - side) return "There is no draw offer to answer.";
        if (accept) end("1/2-1/2", "draw agreed"); else drawOfferBy = -1;
        return null;
    }

    public String offerTakeback(int side) {
        if (over) return "The game is over.";
        if (moves.isEmpty()) return "There is no move to take back.";
        if (pos.side == side && moves.size() < 2) return "There is no move of yours to take back.";
        takebackBy = side;
        return null;
    }

    public String respondTakeback(int side, boolean accept, long now) {
        if (over || takebackBy != 1 - side) return "There is no takeback request to answer.";
        int requester = takebackBy;
        takebackBy = -1;
        if (!accept) return null;
        int plies = pos.side == requester ? 2 : 1;
        if (moves.size() < plies) return "There is no move to take back.";
        // advance the clock to 'now' for the side to move, then restore
        for (int i = 0; i < plies; i++) {
            pos.unplay();
            san.remove(san.size() - 1);
            moves.remove(moves.size() - 1);
            clkAfter.remove(clkAfter.size() - 1);
        }
        if (clkAfter.isEmpty()) { clock[0] = baseMs; clock[1] = baseMs; started = false; lastMove = -1; }
        else { long[] c = clkAfter.get(clkAfter.size() - 1); clock[0] = c[0]; clock[1] = c[1]; lastMove = moves.get(moves.size() - 1); }
        lastTick = now;
        drawOfferBy = -1;
        return null;
    }

    public String pause(long now) {
        if (over) return "The game is over.";
        if (paused) return null;
        if (tick(now)) return null;
        if (started) {
            int s = pos.side;
            clock[s] = Math.max(0, clock[s] - (now - lastTick));
        }
        paused = true;
        return null;
    }

    public String resume(long now) {
        if (over || !paused) return null;
        paused = false;
        lastTick = now;
        return null;
    }

    public void setOnline(int side, boolean online, long now) {
        offlineSince[side] = online ? 0 : Math.max(1, now);
    }

    public boolean claimable(int side, long now) {
        if (over || paused || !started) return false;
        long since = offlineSince[1 - side];
        return since > 0 && now - since >= CLAIM_AFTER_MS;
    }

    public String claim(int side, boolean win, long now) {
        if (!claimable(side, now)) return "You cannot claim yet.";
        if (win) end(side == 0 ? "1-0" : "0-1", "opponent disconnected");
        else end("1/2-1/2", "draw claimed after a disconnect");
        return null;
    }

    public String lastUci() { return lastMove < 0 ? null : Chess.uci(lastMove); }

    // ---------- PGN ----------
    private static String clk(long ms) {
        long s = Math.max(0, ms) / 1000;
        return (s / 3600) + ":" + String.format("%02d", (s / 60) % 60) + ":" + String.format("%02d", s % 60);
    }

    public String pgn(String date) {
        StringBuilder sb = new StringBuilder();
        sb.append("[Event \"Julichess casual game\"]\n");
        sb.append("[Site \"Julichess (local network)\"]\n");
        sb.append("[Date \"").append(date).append("\"]\n");
        sb.append("[Round \"").append(number).append("\"]\n");
        sb.append("[White \"").append(pname[0].replace("\"", "'")).append("\"]\n");
        sb.append("[Black \"").append(pname[1].replace("\"", "'")).append("\"]\n");
        sb.append("[Result \"").append(result).append("\"]\n");
        sb.append("[TimeControl \"").append(baseMs / 1000).append("+").append(incMs / 1000).append("\"]\n");
        if (over && !reason.isEmpty()) sb.append("[Termination \"").append(reason).append("\"]\n");
        sb.append("\n");
        for (int i = 0; i < san.size(); i++) {
            if (i % 2 == 0) sb.append(i / 2 + 1).append(". ");
            sb.append(san.get(i));
            sb.append(" { [%clk ").append(clk(clkAfter.get(i)[i % 2])).append("] } ");
        }
        sb.append(result);
        sb.append("\n");
        return sb.toString();
    }
}
