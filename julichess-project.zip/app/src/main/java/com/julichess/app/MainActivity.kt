package com.julichess.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.UUID

/** Thin shell: shows the web UI and gives it access to Wi-Fi, QR, discovery and the host service. */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("jc", MODE_PRIVATE) }
    private val cm by lazy { getSystemService(ConnectivityManager::class.java) }
    private val nsd by lazy { getSystemService(NsdManager::class.java) }

    private var wifiCb: ConnectivityManager.NetworkCallback? = null
    private var discovery: NsdManager.DiscoveryListener? = null
    private val found = LinkedHashMap<String, JSONObject>()
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    private val scan = registerForActivityResult(ScanContract()) { r ->
        r.contents?.let { emit("qr", JSONObject().put("text", it)) }
    }
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        WebView.setWebContentsDebuggingEnabled(true)
        web.addJavascriptInterface(Bridge(), "JBridge")
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.onBack?window.onBack():false)") {
                    if (it != "true") finish()
                }
            }
        })

        if (Build.VERSION.SDK_INT >= 33) {
            perms.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.NEARBY_WIFI_DEVICES))
        }
    }

    override fun onDestroy() {
        endDiscovery()
        leaveWifi()
        super.onDestroy()
    }

    // ---- native -> web ----
    private fun emit(type: String, data: JSONObject = JSONObject()) {
        data.put("type", type)
        val js = "window.onNative&&window.onNative(" + JSONObject.quote(data.toString()) + ")"
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    // ---- Wi-Fi ----
    private fun joinWifi(ssid: String, pass: String) {
        leaveWifi()
        val spec = WifiNetworkSpecifier.Builder().setSsid(ssid).also {
            if (pass.isNotEmpty()) it.setWpa2Passphrase(pass)
        }.build()
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(spec)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                cm.bindProcessToNetwork(network)
                emit("wifi", JSONObject().put("state", "connected"))
            }
            override fun onUnavailable() {
                emit("wifi", JSONObject().put("state", "failed"))
            }
            override fun onLost(network: Network) {
                cm.bindProcessToNetwork(null)
                emit("wifi", JSONObject().put("state", "lost"))
            }
        }
        wifiCb = cb
        try { cm.requestNetwork(req, cb, 30000) } catch (_: Exception) {
            emit("wifi", JSONObject().put("state", "failed"))
        }
    }

    private fun leaveWifi() {
        wifiCb?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        wifiCb = null
        try { cm.bindProcessToNetwork(null) } catch (_: Exception) {}
    }

    // ---- discovery of hosts on the current network ----
    private fun beginDiscovery() {
        endDiscovery()
        synchronized(found) { found.clear() }
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onServiceFound(s: NsdServiceInfo) {
                synchronized(queue) { queue.addLast(s) }
                resolveNext()
            }
            override fun onServiceLost(s: NsdServiceInfo) {
                synchronized(found) { found.remove(s.serviceName) }
                pushHosts()
            }
        }
        discovery = l
        try { nsd.discoverServices("_julichess._tcp.", NsdManager.PROTOCOL_DNS_SD, l) } catch (_: Exception) {}
    }

    private fun endDiscovery() {
        discovery?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        discovery = null
    }

    private fun resolveNext() {
        var next: NsdServiceInfo? = null
        synchronized(queue) {
            if (!resolving) {
                next = queue.removeFirstOrNull()
                if (next != null) resolving = true
            }
        }
        val item = next ?: return
        try {
            nsd.resolveService(item, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, e: Int) = done()
                override fun onServiceResolved(i: NsdServiceInfo) {
                    val ip = i.host?.hostAddress ?: ""
                    if (ip.isNotEmpty() && !ip.contains(':')) {
                        synchronized(found) {
                            found[i.serviceName] = JSONObject()
                                .put("name", i.serviceName).put("ip", ip).put("port", i.port)
                        }
                        pushHosts()
                    }
                    done()
                }
                private fun done() {
                    synchronized(queue) { resolving = false }
                    resolveNext()
                }
            })
        } catch (_: Exception) {
            synchronized(queue) { resolving = false }
        }
    }

    private fun pushHosts() {
        val arr = JSONArray()
        synchronized(found) { found.values.forEach { arr.put(it) } }
        emit("hosts", JSONObject().put("list", arr))
    }

    private fun findHostAddress(): String {
        val c = ArrayList<Pair<String, String>>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && a.isSiteLocalAddress) c.add(ni.name to (a.hostAddress ?: ""))
                }
            }
        } catch (_: Exception) {}
        val best = c.firstOrNull { it.first.startsWith("ap") || it.first.startsWith("swlan") || it.first.startsWith("wlan1") }
            ?: c.firstOrNull { it.second.startsWith("192.168.43.") }
            ?: c.firstOrNull { it.first.startsWith("wlan") }
        return best?.second ?: ""
    }

    // ---- web -> native ----
    inner class Bridge {
        @JavascriptInterface
        fun deviceId(): String = prefs.getString("id", null)
            ?: UUID.randomUUID().toString().also { prefs.edit().putString("id", it).apply() }

        @JavascriptInterface
        fun hostAddress(): String = findHostAddress()

        @JavascriptInterface
        fun startHosting(name: String, token: String) {
            HostService.start(this@MainActivity, name, token)
        }

        @JavascriptInterface
        fun stopHosting() {
            HostService.stop(this@MainActivity)
        }

        @JavascriptInterface
        fun qrFor(ssid: String, pass: String, ip: String, port: String, name: String): String {
            val text = Uri.Builder().scheme("julichess").authority("join")
                .appendQueryParameter("s", ssid).appendQueryParameter("p", pass)
                .appendQueryParameter("h", ip).appendQueryParameter("port", port)
                .appendQueryParameter("n", name).build().toString()
            val size = 512
            val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
            val px = IntArray(size * size) { i -> if (m.get(i % size, i / size)) Color.BLACK else Color.WHITE }
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            bmp.setPixels(px, 0, size, 0, 0, size, size)
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        }

        @JavascriptInterface
        fun scanQr() {
            runOnUiThread {
                scan.launch(
                    ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                        .setBeepEnabled(false).setOrientationLocked(false)
                        .setPrompt("Scan the host's QR code")
                )
            }
        }

        @JavascriptInterface
        fun openHotspotSettings() {
            runOnUiThread {
                try {
                    startActivity(Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"))
                } catch (_: Exception) {
                    try { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } catch (_: Exception) {}
                }
            }
        }

        @JavascriptInterface
        fun joinWifi(ssid: String, pass: String) {
            runOnUiThread { this@MainActivity.joinWifi(ssid, pass) }
        }

        @JavascriptInterface
        fun leaveWifi() {
            runOnUiThread { this@MainActivity.leaveWifi() }
        }

        @JavascriptInterface
        fun startDiscovery() {
            runOnUiThread { beginDiscovery() }
        }

        @JavascriptInterface
        fun stopDiscovery() {
            runOnUiThread { endDiscovery() }
        }

        @JavascriptInterface
        fun copyText(t: String) {
            runOnUiThread {
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("Julichess log", t))
            }
        }
    }
}
