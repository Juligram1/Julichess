package com.julichess.app

import android.os.SystemClock
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.InetSocketAddress
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * The host's server. Enforces host approval, runs every game (rules and clocks live here),
 * keeps the host log and saves a PGN file for each finished game.
 */
class RoomServer(
    port: Int,
    private val serverName: String,
    private val hostToken: String,
    private val pgnDir: File?
) : WebSocketServer(InetSocketAddress(port)) {

    private class Peer(
        var id: String = "",
        var name: String = "",
        var state: String = "new", // new, pending, approved, rejected, removed
        var host: Boolean = false,
        var watching: String = ""
    )

    private val peers = HashMap<WebSocket, Peer>()
    private val tokens = HashMap<String, String>()       // deviceId -> session token
    private val names = LinkedHashMap<String, String>()  // deviceId -> name (approved members)
    private val logs = ArrayList<String>()
    private val games = LinkedHashMap<String, Game>()
    private val pgnAsks = HashSet<String>()              // "gameId|deviceId"
    private var gameCounter = 0
    private var hostId = ""
    private var ticker: ScheduledExecutorService? = null
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    init {
        isReuseAddr = true
        connectionLostTimeout = 10
    }

    private fun now(): Long = SystemClock.elapsedRealtime()

    // ---------- logging and sending ----------
    @Synchronized
    private fun log(text: String) {
        val line = clock.format(Date()) + "  " + text
        logs.add(line)
        if (logs.size > 500) logs.removeAt(0)
        hostConn()?.let { send(it, JSONObject().put("t", "log").put("line", line)) }
    }

    private fun hostConn(): WebSocket? =
        peers.entries.firstOrNull { it.value.host && it.value.state == "approved" }?.key

    private fun send(c: WebSocket, o: JSONObject) {
        try { if (c.isOpen) c.send(o.toString()) } catch (_: Exception) {}
    }

    private fun sendAll(o: JSONObject) {
        for ((c, p) in peers) if (p.state == "approved") send(c, o)
    }

    private fun isOnline(id: String) = peers.values.any { it.id == id && it.state == "approved" }

    // ---------- roster ----------
    private fun rosterJson(): JSONArray {
        val arr = JSONArray()
        val online = peers.values.filter { it.state == "approved" }.map { it.id }.toSet()
        for ((id, n) in names) {
            arr.put(
                JSONObject().put("deviceId", id).put("name", n)
                    .put("online", id in online).put("isHost", id == hostId)
            )
        }
        return arr
    }

    private fun broadcastRoster() {
        sendAll(JSONObject().put("t", "roster").put("members", rosterJson()))
    }

    private fun welcome(c: WebSocket, p: Peer, token: String) {
        p.state = "approved"
        names[p.id] = p.name
        send(
            c, JSONObject().put("t", "welcome").put("serverName", serverName)
                .put("role", if (p.host) "host" else "guest")
                .put("token", token).put("roster", rosterJson())
        )
        broadcastRoster()
        send(c, gamesJson())
        val n = now()
        for (g in games.values) {
            val role = roleOf(g, p.id)
            if (role >= 0 && !g.over) {
                g.setOnline(role, true, n)
                g.claimNotified[1 - role] = false
                send(c, gameJson(g, p.id))
                pushGame(g)
            }
        }
    }

    // ---------- games ----------
    private fun roleOf(g: Game, id: String): Int = if (g.pid[0] == id) 0 else if (g.pid[1] == id) 1 else -1

    private fun tcText(baseSec: Long, incSec: Long): String =
        (if (baseSec % 60 == 0L) "${baseSec / 60}" else "${baseSec}s") + "+" + incSec

    private fun gameJson(g: Game, viewer: String): JSONObject {
        val n = now()
        val role = roleOf(g, viewer)
        val mover = g.pos.side
        val canMove = role == mover && !g.over && !g.paused
        val watchers = peers.values
            .filter { it.state == "approved" && it.watching == g.id && roleOf(g, it.id) < 0 }
            .map { it.id }.toSet().size
        return JSONObject().put("t", "game").put("id", g.id).put("number", g.number)
            .put("white", JSONObject().put("id", g.pid[0]).put("name", g.pname[0]).put("online", g.offlineSince[0] == 0L))
            .put("black", JSONObject().put("id", g.pid[1]).put("name", g.pname[1]).put("online", g.offlineSince[1] == 0L))
            .put("base", g.baseMs / 1000).put("inc", g.incMs / 1000)
            .put("fen", g.pos.fen())
            .put("legal", JSONArray(if (canMove) g.pos.legalUci() else emptyList<String>()))
            .put("last", g.lastUci() ?: JSONObject.NULL)
            .put("check", g.pos.inCheck())
            .put("san", JSONArray(g.san))
            .put("clocks", JSONArray().put(g.remaining(0, n)).put(g.remaining(1, n)))
            .put("turn", if (mover == 0) "w" else "b")
            .put("started", g.started)
            .put("status", if (g.over) "over" else if (g.paused) "paused" else "active")
            .put("result", g.result).put("reason", g.reason)
            .put("drawBy", g.drawOfferBy).put("tbBy", g.takebackBy)
            .put("you", role)
            .put("claim", role >= 0 && g.claimable(role, n))
            .put("watching", watchers)
    }

    private fun gamesJson(): JSONObject {
        val arr = JSONArray()
        for (g in games.values) {
            arr.put(
                JSONObject().put("id", g.id).put("number", g.number)
                    .put("white", g.pname[0]).put("black", g.pname[1])
                    .put("tc", tcText(g.baseMs / 1000, g.incMs / 1000))
                    .put("status", if (g.over) "over" else if (g.paused) "paused" else "active")
                    .put("result", g.result)
                    .put("whiteId", g.pid[0]).put("blackId", g.pid[1])
            )
        }
        return JSONObject().put("t", "games").put("list", arr)
    }

    private fun pushGames() = sendAll(gamesJson())

    private fun pushGame(g: Game) {
        for ((c, p) in peers) {
            if (p.state == "approved" && (roleOf(g, p.id) >= 0 || p.watching == g.id)) send(c, gameJson(g, p.id))
        }
    }

    private fun safeName(g: Game): String =
        "Game ${g.number} - ${g.pname[0]} vs ${g.pname[1]}".replace(Regex("[^A-Za-z0-9 _.-]"), "_")

    private fun pgnText(g: Game): String = g.pgn(SimpleDateFormat("yyyy.MM.dd", Locale.US).format(Date()))

    private fun savePgn(g: Game) {
        val dir = pgnDir ?: return
        try {
            dir.mkdirs()
            File(dir, safeName(g) + ".pgn").writeText(pgnText(g))
        } catch (_: Exception) {}
    }

    private fun afterAction(g: Game) {
        if (g.over && !g.reported) {
            g.reported = true
            log("Game ${g.number} ended: ${g.result} (${g.reason})")
            savePgn(g)
        }
        pushGame(g)
        pushGames()
    }

    private fun createGame(wId: String, bId: String, baseSec: Long, incSec: Long): String? {
        if (wId == bId) return "Pick two different players."
        val wn = names[wId]
        val bn = names[bId]
        if (wn == null || bn == null) return "Both players must be in the server."
        if (!isOnline(wId) || !isOnline(bId)) return "Both players must be online."
        if (baseSec < 15 || baseSec > 10800 || incSec < 0 || incSec > 60) return "That time control is out of range."
        gameCounter++
        val g = Game("g$gameCounter", gameCounter, wId, wn, bId, bn, baseSec * 1000, incSec * 1000)
        games[g.id] = g
        log("Game ${g.number} started: $wn (white) vs $bn (black), ${tcText(baseSec, incSec)}")
        pushGames()
        pushGame(g)
        return null
    }

    @Synchronized
    private fun tickAll() {
        val n = now()
        for (g in games.values.toList()) {
            if (g.over) continue
            if (g.tick(n)) { afterAction(g); continue }
            var changed = false
            for (s in 0..1) {
                val c = g.claimable(s, n)
                if (c != g.claimNotified[s]) { g.claimNotified[s] = c; changed = true }
            }
            if (changed) pushGame(g)
        }
    }

    // ---------- websocket callbacks ----------
    @Synchronized
    override fun onStart() {
        log("Server started on port $port")
        ticker = Executors.newSingleThreadScheduledExecutor().also {
            it.scheduleWithFixedDelay({ try { tickAll() } catch (_: Exception) {} }, 500, 250, TimeUnit.MILLISECONDS)
        }
    }

    override fun stop(timeout: Int) {
        try { ticker?.shutdownNow() } catch (_: Exception) {}
        super.stop(timeout)
    }

    @Synchronized
    override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
        peers[conn] = Peer()
    }

    @Synchronized
    override fun onClose(conn: WebSocket, code: Int, reason: String?, remote: Boolean) {
        val p = peers.remove(conn) ?: return
        when {
            p.host -> log("Host screen disconnected")
            p.state == "pending" -> hostConn()?.let {
                send(it, JSONObject().put("t", "joinCancel").put("deviceId", p.id))
            }
            p.state == "approved" ->
                if (peers.values.none { it.id == p.id && it.state == "approved" }) {
                    log("${p.name} disconnected")
                    broadcastRoster()
                    val n = now()
                    for (g in games.values) {
                        val role = roleOf(g, p.id)
                        if (role >= 0 && !g.over) {
                            g.setOnline(role, false, n)
                            log("Game ${g.number}: ${p.name} is offline")
                            pushGame(g)
                        }
                    }
                }
        }
        if (p.state == "approved" && p.watching.isNotEmpty()) games[p.watching]?.let { pushGame(it) }
    }

    @Synchronized
    override fun onError(conn: WebSocket?, ex: Exception) {
        log("Error: ${ex.message}")
    }

    @Synchronized
    override fun onMessage(conn: WebSocket, message: String) {
        val p = peers[conn] ?: return
        val j = try { JSONObject(message) } catch (_: Exception) { return }
        when (j.optString("t")) {
            "hello" -> hello(conn, p, j)
            "decision" -> if (p.host) decide(j.optString("deviceId"), j.optBoolean("approve"))
            "kick" -> if (p.host) kick(j.optString("deviceId"))
            "ping" -> send(conn, JSONObject().put("t", "pong"))
            else -> if (p.state == "approved") gameMessage(conn, p, j)
        }
    }

    private fun hello(conn: WebSocket, p: Peer, j: JSONObject) {
        val id = j.optString("deviceId")
        val name = j.optString("name").trim().take(24).ifBlank { "Player" }
        if (id.isBlank() || p.state != "new") return

        // The same device reconnecting replaces its old connection.
        peers.entries.filter { it.key != conn && it.value.id == id }.forEach {
            try { it.key.close() } catch (_: Exception) {}
        }
        p.id = id
        p.name = name

        if (j.optString("hostToken") == hostToken) {
            p.host = true
            hostId = id
            welcome(conn, p, "")
            send(conn, JSONObject().put("t", "logs").put("lines", JSONArray(logs)))
            peers.values.filter { it.state == "pending" }.forEach {
                send(conn, JSONObject().put("t", "joinRequest").put("deviceId", it.id).put("name", it.name))
            }
            log("Host ready: $name")
            return
        }

        val saved = tokens[id]
        if (saved != null && saved == j.optString("token")) {
            welcome(conn, p, saved)
            log("$name reconnected")
            return
        }
        if (peers.values.count { it.state == "pending" } >= 8) {
            p.state = "rejected"
            send(conn, JSONObject().put("t", "rejected"))
            conn.close()
            return
        }
        p.state = "pending"
        send(conn, JSONObject().put("t", "pending"))
        hostConn()?.let {
            send(it, JSONObject().put("t", "joinRequest").put("deviceId", id).put("name", name))
        }
        log("$name is asking to join")
    }

    private fun decide(id: String, approve: Boolean) {
        val e = peers.entries.firstOrNull { it.value.id == id && it.value.state == "pending" } ?: return
        val c = e.key
        val p = e.value
        if (approve) {
            val t = UUID.randomUUID().toString()
            tokens[id] = t
            welcome(c, p, t)
            log("${p.name} joined")
        } else {
            p.state = "rejected"
            send(c, JSONObject().put("t", "rejected"))
            log("${p.name} was declined")
            c.close()
        }
    }

    private fun kick(id: String) {
        if (id == hostId) return
        tokens.remove(id)
        val nm = names.remove(id) ?: "A player"
        peers.entries.filter { it.value.id == id }.forEach {
            send(it.key, JSONObject().put("t", "kicked"))
            it.value.state = "removed"
            it.key.close()
        }
        log("$nm was removed")
        broadcastRoster()
    }

    // ---------- game messages ----------
    private fun act(conn: WebSocket, p: Peer, j: JSONObject, needPlayer: Boolean, f: (Game, Int) -> String?) {
        val g = games[j.optString("gameId")] ?: return
        val role = roleOf(g, p.id)
        val err = if (needPlayer && role < 0) "You are not playing in this game." else f(g, role)
        if (err != null) send(conn, JSONObject().put("t", "err").put("msg", err))
        afterAction(g)
    }

    private fun gameMessage(conn: WebSocket, p: Peer, j: JSONObject) {
        val uciRe = Regex("^[a-h][1-8][a-h][1-8][qrbn]?$")
        when (j.optString("t")) {
            "newGame" -> {
                if (!p.host) return
                val err = createGame(j.optString("white"), j.optString("black"), j.optLong("base"), j.optLong("inc"))
                if (err != null) send(conn, JSONObject().put("t", "err").put("msg", err))
            }
            "rematch" -> {
                if (!p.host) return
                val g = games[j.optString("gameId")] ?: return
                if (!g.over) return
                val err = createGame(g.pid[1], g.pid[0], g.baseMs / 1000, g.incMs / 1000)
                if (err != null) send(conn, JSONObject().put("t", "err").put("msg", err))
            }
            "watch" -> {
                val old = p.watching
                p.watching = j.optString("gameId")
                games[old]?.let { pushGame(it) }
                games[p.watching]?.let { send(conn, gameJson(it, p.id)); pushGame(it) }
            }
            "unwatch" -> {
                val old = p.watching
                p.watching = ""
                games[old]?.let { pushGame(it) }
            }
            "move" -> act(conn, p, j, true) { g, r ->
                val u = j.optString("uci")
                if (!uciRe.matches(u)) "That move is not legal."
                else g.move(r, Chess.sq(u.substring(0, 2)), Chess.sq(u.substring(2, 4)),
                    if (u.length > 4) Chess.promoOf(u[4]) else 0, now())
            }
            "resign" -> act(conn, p, j, true) { g, r ->
                g.resign(r).also { if (it == null) log("Game ${g.number}: ${p.name} resigned") }
            }
            "drawOffer" -> act(conn, p, j, true) { g, r -> g.offerDraw(r) }
            "drawReply" -> act(conn, p, j, true) { g, r -> g.respondDraw(r, j.optBoolean("accept")) }
            "tbOffer" -> act(conn, p, j, true) { g, r -> g.offerTakeback(r) }
            "tbReply" -> act(conn, p, j, true) { g, r ->
                g.respondTakeback(r, j.optBoolean("accept"), now()).also {
                    if (it == null && j.optBoolean("accept")) log("Game ${g.number}: takeback accepted")
                }
            }
            "claim" -> act(conn, p, j, true) { g, r ->
                g.claim(r, j.optString("kind") == "win", now()).also {
                    if (it == null) log("Game ${g.number}: ${p.name} claimed after a disconnect")
                }
            }
            "pause" -> act(conn, p, j, false) { g, _ ->
                if (!p.host) "Only the host can pause a game."
                else if (j.optBoolean("on")) { g.pause(now()).also { log("Game ${g.number} paused by host") } }
                else { g.resume(now()).also { log("Game ${g.number} resumed by host") } }
            }
            "abort" -> act(conn, p, j, false) { g, _ ->
                if (!p.host) "Only the host can end a game." else g.abort()
            }
            "pgnReq" -> {
                val g = games[j.optString("gameId")] ?: return
                if (p.host) sendPgn(conn, g)
                else {
                    pgnAsks.add(g.id + "|" + p.id)
                    hostConn()?.let {
                        send(it, JSONObject().put("t", "pgnAsk").put("gameId", g.id).put("deviceId", p.id)
                            .put("name", p.name).put("label", "Game ${g.number}"))
                    }
                    log("${p.name} asked for the PGN of game ${g.number}")
                }
            }
            "pgnDecision" -> {
                if (!p.host) return
                val gid = j.optString("gameId")
                val id = j.optString("deviceId")
                val g = games[gid] ?: return
                if (!pgnAsks.remove("$gid|$id")) return
                for ((c, q) in peers) {
                    if (q.id == id && q.state == "approved") {
                        if (j.optBoolean("approve")) sendPgn(c, g) else send(c, JSONObject().put("t", "pgnDenied"))
                    }
                }
            }
        }
    }

    private fun sendPgn(c: WebSocket, g: Game) {
        send(c, JSONObject().put("t", "pgn").put("gameId", g.id)
            .put("filename", safeName(g) + ".pgn").put("text", pgnText(g)))
    }
}
