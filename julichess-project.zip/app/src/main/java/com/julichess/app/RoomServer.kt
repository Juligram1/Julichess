package com.julichess.app

import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * The host's server. Enforces host approval: a new device can only say hello
 * until the host accepts it. Also keeps the host log.
 */
class RoomServer(
    port: Int,
    private val serverName: String,
    private val hostToken: String
) : WebSocketServer(InetSocketAddress(port)) {

    private class Peer(
        var id: String = "",
        var name: String = "",
        var state: String = "new", // new, pending, approved, rejected, removed
        var host: Boolean = false
    )

    private val peers = HashMap<WebSocket, Peer>()
    private val tokens = HashMap<String, String>()       // deviceId -> session token
    private val names = LinkedHashMap<String, String>()  // deviceId -> name (approved members)
    private val logs = ArrayList<String>()
    private var hostId = ""
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    init {
        isReuseAddr = true
        connectionLostTimeout = 10
    }

    @Synchronized
    private fun log(text: String) {
        val line = clock.format(Date()) + "  " + text
        logs.add(line)
        if (logs.size > 500) logs.removeAt(0)
        hostConn()?.let { send(it, JSONObject().put("t", "log").put("line", line)) }
    }

    private fun hostConn(): WebSocket? =
        peers.entries.firstOrNull { it.value.host && it.value.state == "approved" }?.key

    private fun send(c: WebSocket, o: JSONObject) {
        try { if (c.isOpen) c.send(o.toString()) } catch (_: Exception) {}
    }

    private fun rosterJson(): JSONArray {
        val arr = JSONArray()
        val online = peers.values.filter { it.state == "approved" }.map { it.id }.toSet()
        for ((id, n) in names) {
            arr.put(
                JSONObject().put("deviceId", id).put("name", n)
                    .put("online", id in online).put("isHost", id == hostId)
            )
        }
        return arr
    }

    private fun broadcastRoster() {
        val msg = JSONObject().put("t", "roster").put("members", rosterJson())
        for ((c, p) in peers) if (p.state == "approved") send(c, msg)
    }

    private fun welcome(c: WebSocket, p: Peer, token: String) {
        p.state = "approved"
        names[p.id] = p.name
        send(
            c, JSONObject().put("t", "welcome").put("serverName", serverName)
                .put("role", if (p.host) "host" else "guest")
                .put("token", token).put("roster", rosterJson())
        )
        broadcastRoster()
    }

    @Synchronized
    override fun onStart() {
        log("Server started on port $port")
    }

    @Synchronized
    override fun onOpen(conn: WebSocket, handshake: ClientHandshake) {
        peers[conn] = Peer()
    }

    @Synchronized
    override fun onClose(conn: WebSocket, code: Int, reason: String?, remote: Boolean) {
        val p = peers.remove(conn) ?: return
        when {
            p.host -> log("Host screen disconnected")
            p.state == "pending" -> hostConn()?.let {
                send(it, JSONObject().put("t", "joinCancel").put("deviceId", p.id))
            }
            p.state == "approved" ->
                if (peers.values.none { it.id == p.id && it.state == "approved" }) {
                    log("${p.name} disconnected")
                    broadcastRoster()
                }
        }
    }

    @Synchronized
    override fun onError(conn: WebSocket?, ex: Exception) {
        log("Error: ${ex.message}")
    }

    @Synchronized
    override fun onMessage(conn: WebSocket, message: String) {
        val p = peers[conn] ?: return
        val j = try { JSONObject(message) } catch (_: Exception) { return }
        when (j.optString("t")) {
            "hello" -> hello(conn, p, j)
            "decision" -> if (p.host) decide(j.optString("deviceId"), j.optBoolean("approve"))
            "kick" -> if (p.host) kick(j.optString("deviceId"))
            "ping" -> send(conn, JSONObject().put("t", "pong"))
        }
    }

    private fun hello(conn: WebSocket, p: Peer, j: JSONObject) {
        val id = j.optString("deviceId")
        val name = j.optString("name").trim().take(24).ifBlank { "Player" }
        if (id.isBlank() || p.state != "new") return

        // The same device reconnecting replaces its old connection.
        peers.entries.filter { it.key != conn && it.value.id == id }.forEach {
            try { it.key.close() } catch (_: Exception) {}
        }
        p.id = id
        p.name = name

        if (j.optString("hostToken") == hostToken) {
            p.host = true
            hostId = id
            welcome(conn, p, "")
            send(conn, JSONObject().put("t", "logs").put("lines", JSONArray(logs)))
            peers.values.filter { it.state == "pending" }.forEach {
                send(conn, JSONObject().put("t", "joinRequest").put("deviceId", it.id).put("name", it.name))
            }
            log("Host ready: $name")
            return
        }

        val saved = tokens[id]
        if (saved != null && saved == j.optString("token")) {
            welcome(conn, p, saved)
            log("$name reconnected")
            return
        }
        if (peers.values.count { it.state == "pending" } >= 8) {
            p.state = "rejected"
            send(conn, JSONObject().put("t", "rejected"))
            conn.close()
            return
        }
        p.state = "pending"
        send(conn, JSONObject().put("t", "pending"))
        hostConn()?.let {
            send(it, JSONObject().put("t", "joinRequest").put("deviceId", id).put("name", name))
        }
        log("$name is asking to join")
    }

    private fun decide(id: String, approve: Boolean) {
        val e = peers.entries.firstOrNull { it.value.id == id && it.value.state == "pending" } ?: return
        val c = e.key
        val p = e.value
        if (approve) {
            val t = UUID.randomUUID().toString()
            tokens[id] = t
            welcome(c, p, t)
            log("${p.name} joined")
        } else {
            p.state = "rejected"
            send(c, JSONObject().put("t", "rejected"))
            log("${p.name} was declined")
            c.close()
        }
    }

    private fun kick(id: String) {
        if (id == hostId) return
        tokens.remove(id)
        val nm = names.remove(id) ?: "A player"
        peers.entries.filter { it.value.id == id }.forEach {
            send(it.key, JSONObject().put("t", "kicked"))
            it.value.state = "removed"
            it.key.close()
        }
        log("$nm was removed")
        broadcastRoster()
    }
}
