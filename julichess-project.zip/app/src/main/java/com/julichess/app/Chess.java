package com.julichess.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Pure-Java chess rules: legal moves, SAN, FEN, draws and mate detection. No Android dependencies. */
public final class Chess {
    public static final int P = 1, N = 2, B = 3, R = 4, Q = 5, K = 6;

    /** Squares 0..63, a1 = 0, h1 = 7, a8 = 56. Positive = white piece, negative = black piece. */
    public final int[] b = new int[64];
    public int side;      // 0 white to move, 1 black to move
    public int castle;    // 1 = white short, 2 = white long, 4 = black short, 8 = black long
    public int ep = -1;   // en passant target square or -1
    public int half;      // half-move clock
    public int full = 1;  // full-move number

    private static final class Undo { int move, piece, cap, capSq, castle, ep, half, full; }

    private final ArrayList<Undo> stack = new ArrayList<>();
    private final ArrayList<String> keys = new ArrayList<>();

    private static final int[] KN_F = {1, 2, 2, 1, -1, -2, -2, -1};
    private static final int[] KN_R = {2, 1, -1, -2, -2, -1, 1, 2};
    private static final int[] DG_F = {1, 1, -1, -1};
    private static final int[] DG_R = {1, -1, 1, -1};
    private static final int[] OR_F = {1, -1, 0, 0};
    private static final int[] OR_R = {0, 0, 1, -1};

    private Chess() {}

    public static Chess start() {
        return fromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
    }

    public static Chess fromFen(String fen) {
        Chess c = new Chess();
        String[] p = fen.trim().split("\\s+");
        String[] rows = p[0].split("/");
        for (int i = 0; i < 8; i++) {
            int r = 7 - i, f = 0;
            for (char ch : rows[i].toCharArray()) {
                if (Character.isDigit(ch)) f += ch - '0';
                else {
                    int t = "pnbrqk".indexOf(Character.toLowerCase(ch)) + 1;
                    c.b[r * 8 + f] = Character.isUpperCase(ch) ? t : -t;
                    f++;
                }
            }
        }
        c.side = p[1].equals("w") ? 0 : 1;
        for (char ch : p[2].toCharArray()) {
            switch (ch) {
                case 'K': c.castle |= 1; break;
                case 'Q': c.castle |= 2; break;
                case 'k': c.castle |= 4; break;
                case 'q': c.castle |= 8; break;
                default: break;
            }
        }
        if (p.length > 3 && !p[3].equals("-")) c.ep = (p[3].charAt(1) - '1') * 8 + (p[3].charAt(0) - 'a');
        c.half = p.length > 4 ? Integer.parseInt(p[4]) : 0;
        c.full = p.length > 5 ? Integer.parseInt(p[5]) : 1;
        c.keys.add(c.key());
        return c;
    }

    // ---------- helpers ----------
    public static String sqName(int sq) {
        return "" + (char) ('a' + (sq & 7)) + (char) ('1' + (sq >> 3));
    }

    public static int sq(String s) {
        return (s.charAt(1) - '1') * 8 + (s.charAt(0) - 'a');
    }

    public static int promoOf(char c) {
        return "nbrq".indexOf(Character.toLowerCase(c)) < 0 ? 0 : new int[]{N, B, R, Q}["nbrq".indexOf(Character.toLowerCase(c))];
    }

    private static char letter(int type) { return "PNBRQK".charAt(type - 1); }

    public static String uci(int m) {
        int promo = (m >> 12) & 7;
        return sqName(m & 63) + sqName((m >> 6) & 63) + (promo == 0 ? "" : String.valueOf(Character.toLowerCase(letter(promo))));
    }

    private static int rightsMask(int sq) {
        switch (sq) {
            case 4: return 3;
            case 0: return 2;
            case 7: return 1;
            case 60: return 12;
            case 56: return 8;
            case 63: return 4;
            default: return 0;
        }
    }

    // ---------- attacks ----------
    private boolean attacked(int sq, int by) {
        int f = sq & 7, r = sq >> 3;
        int sign = by == 0 ? 1 : -1;
        int pr = by == 0 ? r - 1 : r + 1;
        if (pr >= 0 && pr < 8) {
            for (int df = -1; df <= 1; df += 2) {
                int pf = f + df;
                if (pf >= 0 && pf < 8 && b[pr * 8 + pf] == sign * P) return true;
            }
        }
        for (int i = 0; i < 8; i++) {
            int nf = f + KN_F[i], nr = r + KN_R[i];
            if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8 && b[nr * 8 + nf] == sign * N) return true;
        }
        for (int i = 0; i < 4; i++) {
            int nf = f + DG_F[i], nr = r + DG_R[i];
            if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8 && b[nr * 8 + nf] == sign * K) return true;
            nf = f + OR_F[i]; nr = r + OR_R[i];
            if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8 && b[nr * 8 + nf] == sign * K) return true;
        }
        for (int i = 0; i < 4; i++) {
            int nf = f + DG_F[i], nr = r + DG_R[i];
            while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                int pc = b[nr * 8 + nf];
                if (pc != 0) { if (pc == sign * B || pc == sign * Q) return true; break; }
                nf += DG_F[i]; nr += DG_R[i];
            }
            nf = f + OR_F[i]; nr = r + OR_R[i];
            while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                int pc = b[nr * 8 + nf];
                if (pc != 0) { if (pc == sign * R || pc == sign * Q) return true; break; }
                nf += OR_F[i]; nr += OR_R[i];
            }
        }
        return false;
    }

    private boolean inCheckColor(int color) {
        int target = color == 0 ? K : -K;
        for (int s = 0; s < 64; s++) if (b[s] == target) return attacked(s, 1 - color);
        return false;
    }

    public boolean inCheck() { return inCheckColor(side); }

    // ---------- move generation ----------
    private int addPawn(int[] out, int n, int from, int to, boolean promo) {
        if (promo) {
            out[n++] = from | (to << 6) | (Q << 12);
            out[n++] = from | (to << 6) | (R << 12);
            out[n++] = from | (to << 6) | (B << 12);
            out[n++] = from | (to << 6) | (N << 12);
        } else out[n++] = from | (to << 6);
        return n;
    }

    private int gen(int[] out) {
        int n = 0;
        for (int sq = 0; sq < 64; sq++) {
            int pc = b[sq];
            if (pc == 0 || (pc > 0) != (side == 0)) continue;
            int t = Math.abs(pc), f = sq & 7, r = sq >> 3;
            if (t == P) {
                int dir = side == 0 ? 1 : -1, startR = side == 0 ? 1 : 6, lastR = side == 0 ? 7 : 0;
                int r1 = r + dir;
                if (r1 < 0 || r1 > 7) continue;
                int to = r1 * 8 + f;
                if (b[to] == 0) {
                    n = addPawn(out, n, sq, to, r1 == lastR);
                    int to2 = (r + 2 * dir) * 8 + f;
                    if (r == startR && b[to2] == 0) out[n++] = sq | (to2 << 6);
                }
                for (int df = -1; df <= 1; df += 2) {
                    int nf = f + df;
                    if (nf < 0 || nf > 7) continue;
                    int tt = r1 * 8 + nf, tp = b[tt];
                    if (tp != 0 && (tp > 0) != (side == 0)) n = addPawn(out, n, sq, tt, r1 == lastR);
                    else if (tp == 0 && tt == ep) out[n++] = sq | (tt << 6);
                }
            } else if (t == N) {
                for (int i = 0; i < 8; i++) {
                    int nf = f + KN_F[i], nr = r + KN_R[i];
                    if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
                    int tt = nr * 8 + nf, tp = b[tt];
                    if (tp == 0 || (tp > 0) != (side == 0)) out[n++] = sq | (tt << 6);
                }
            } else if (t == K) {
                for (int i = 0; i < 4; i++) {
                    for (int k = 0; k < 2; k++) {
                        int nf = f + (k == 0 ? DG_F[i] : OR_F[i]), nr = r + (k == 0 ? DG_R[i] : OR_R[i]);
                        if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
                        int tt = nr * 8 + nf, tp = b[tt];
                        if (tp == 0 || (tp > 0) != (side == 0)) out[n++] = sq | (tt << 6);
                    }
                }
                if (side == 0 && sq == 4) {
                    if ((castle & 1) != 0 && b[5] == 0 && b[6] == 0 && b[7] == R && !attacked(4, 1) && !attacked(5, 1))
                        out[n++] = 4 | (6 << 6);
                    if ((castle & 2) != 0 && b[3] == 0 && b[2] == 0 && b[1] == 0 && b[0] == R && !attacked(4, 1) && !attacked(3, 1))
                        out[n++] = 4 | (2 << 6);
                } else if (side == 1 && sq == 60) {
                    if ((castle & 4) != 0 && b[61] == 0 && b[62] == 0 && b[63] == -R && !attacked(60, 0) && !attacked(61, 0))
                        out[n++] = 60 | (62 << 6);
                    if ((castle & 8) != 0 && b[59] == 0 && b[58] == 0 && b[57] == 0 && b[56] == -R && !attacked(60, 0) && !attacked(59, 0))
                        out[n++] = 60 | (58 << 6);
                }
            } else {
                boolean diag = t == B || t == Q, orth = t == R || t == Q;
                for (int i = 0; i < 4; i++) {
                    for (int k = 0; k < 2; k++) {
                        if ((k == 0 && !diag) || (k == 1 && !orth)) continue;
                        int df = k == 0 ? DG_F[i] : OR_F[i], dr = k == 0 ? DG_R[i] : OR_R[i];
                        int nf = f + df, nr = r + dr;
                        while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
                            int tt = nr * 8 + nf, tp = b[tt];
                            if (tp == 0) out[n++] = sq | (tt << 6);
                            else {
                                if ((tp > 0) != (side == 0)) out[n++] = sq | (tt << 6);
                                break;
                            }
                            nf += df; nr += dr;
                        }
                    }
                }
            }
        }
        return n;
    }

    // ---------- make / undo (low level) ----------
    private void make(int m) {
        int from = m & 63, to = (m >> 6) & 63, promo = (m >> 12) & 7;
        int piece = b[from], type = Math.abs(piece), col = piece > 0 ? 0 : 1;
        Undo u = new Undo();
        u.move = m; u.piece = piece; u.castle = castle; u.ep = ep; u.half = half; u.full = full;
        int capSq = to, cap = b[to];
        if (type == P && ep != -1 && to == ep && cap == 0 && (from & 7) != (to & 7)) {
            capSq = col == 0 ? to - 8 : to + 8;
            cap = b[capSq];
        }
        u.cap = cap; u.capSq = capSq;
        b[capSq] = 0;
        b[from] = 0;
        b[to] = promo != 0 ? (col == 0 ? promo : -promo) : piece;
        if (type == K && Math.abs(to - from) == 2) {
            if (to > from) { b[from + 1] = b[from + 3]; b[from + 3] = 0; }
            else { b[from - 1] = b[from - 4]; b[from - 4] = 0; }
        }
        castle &= ~rightsMask(from) & ~rightsMask(to);
        ep = (type == P && Math.abs(to - from) == 16) ? (from + to) / 2 : -1;
        half = (type == P || cap != 0) ? 0 : half + 1;
        if (col == 1) full++;
        side ^= 1;
        stack.add(u);
    }

    private void undo() {
        Undo u = stack.remove(stack.size() - 1);
        side ^= 1;
        int from = u.move & 63, to = (u.move >> 6) & 63;
        int type = Math.abs(u.piece);
        b[to] = 0;
        b[from] = u.piece;
        if (u.cap != 0) b[u.capSq] = u.cap;
        if (type == K && Math.abs(to - from) == 2) {
            if (to > from) { b[from + 3] = b[from + 1]; b[from + 1] = 0; }
            else { b[from - 4] = b[from - 1]; b[from - 1] = 0; }
        }
        castle = u.castle; ep = u.ep; half = u.half; full = u.full;
    }

    // ---------- public API ----------
    public int[] legalMoves() {
        int[] buf = new int[256];
        int n = gen(buf);
        int[] res = new int[n];
        int c = 0, mover = side;
        for (int i = 0; i < n; i++) {
            make(buf[i]);
            boolean ok = !inCheckColor(mover);
            undo();
            if (ok) res[c++] = buf[i];
        }
        return Arrays.copyOf(res, c);
    }

    public List<String> legalUci() {
        ArrayList<String> out = new ArrayList<>();
        for (int m : legalMoves()) out.add(uci(m));
        return out;
    }

    /** Finds the legal move; a pawn reaching the last rank with no piece chosen becomes a queen. */
    public int find(int from, int to, int promo) {
        int[] lm = legalMoves();
        for (int m : lm) if ((m & 63) == from && ((m >> 6) & 63) == to && ((m >> 12) & 7) == promo) return m;
        if (promo == 0) {
            for (int m : lm) if ((m & 63) == from && ((m >> 6) & 63) == to && ((m >> 12) & 7) == Q) return m;
        }
        return -1;
    }

    public void play(int m) { make(m); keys.add(key()); }

    public void unplay() { undo(); keys.remove(keys.size() - 1); }

    public long perft(int d) {
        if (d == 0) return 1;
        int[] buf = new int[256];
        int n = gen(buf), mover = side;
        long cnt = 0;
        for (int i = 0; i < n; i++) {
            make(buf[i]);
            if (!inCheckColor(mover)) cnt += d == 1 ? 1 : perft(d - 1);
            undo();
        }
        return cnt;
    }

    /** SAN for a legal move in the current position (call before playing it). */
    public String san(int m) {
        int from = m & 63, to = (m >> 6) & 63, promo = (m >> 12) & 7;
        int piece = b[from], type = Math.abs(piece);
        StringBuilder sb = new StringBuilder();
        if (type == K && Math.abs(to - from) == 2) sb.append(to > from ? "O-O" : "O-O-O");
        else {
            boolean capture = b[to] != 0 || (type == P && ep != -1 && to == ep && (from & 7) != (to & 7));
            if (type == P) {
                if (capture) sb.append((char) ('a' + (from & 7))).append('x');
                sb.append(sqName(to));
                if (promo != 0) sb.append('=').append(letter(promo));
            } else {
                sb.append(letter(type));
                boolean any = false, sameFile = false, sameRank = false;
                for (int o : legalMoves()) {
                    int of = o & 63;
                    if (o == m || ((o >> 6) & 63) != to || Math.abs(b[of]) != type || of == from) continue;
                    any = true;
                    if ((of & 7) == (from & 7)) sameFile = true;
                    if ((of >> 3) == (from >> 3)) sameRank = true;
                }
                if (any) {
                    if (!sameFile) sb.append((char) ('a' + (from & 7)));
                    else if (!sameRank) sb.append((char) ('1' + (from >> 3)));
                    else sb.append(sqName(from));
                }
                if (capture) sb.append('x');
                sb.append(sqName(to));
            }
        }
        make(m);
        if (inCheckColor(side)) {
            boolean has = false;
            int[] buf = new int[256];
            int n = gen(buf), mover = side;
            for (int i = 0; i < n && !has; i++) {
                make(buf[i]);
                if (!inCheckColor(mover)) has = true;
                undo();
            }
            sb.append(has ? "+" : "#");
        }
        undo();
        return sb.toString();
    }

    public String fen() {
        StringBuilder sb = new StringBuilder(placement());
        sb.append(side == 0 ? " w " : " b ").append(castleStr()).append(' ');
        sb.append(ep >= 0 ? sqName(ep) : "-").append(' ').append(half).append(' ').append(full);
        return sb.toString();
    }

    private String placement() {
        StringBuilder sb = new StringBuilder();
        for (int r = 7; r >= 0; r--) {
            int empty = 0;
            for (int f = 0; f < 8; f++) {
                int pc = b[r * 8 + f];
                if (pc == 0) { empty++; continue; }
                if (empty > 0) { sb.append(empty); empty = 0; }
                char ch = letter(Math.abs(pc));
                sb.append(pc > 0 ? ch : Character.toLowerCase(ch));
            }
            if (empty > 0) sb.append(empty);
            if (r > 0) sb.append('/');
        }
        return sb.toString();
    }

    private String castleStr() {
        String s = ((castle & 1) != 0 ? "K" : "") + ((castle & 2) != 0 ? "Q" : "") + ((castle & 4) != 0 ? "k" : "") + ((castle & 8) != 0 ? "q" : "");
        return s.isEmpty() ? "-" : s;
    }

    private boolean epCapturePossible() {
        if (ep < 0) return false;
        int f = ep & 7, r = ep >> 3, pr = side == 0 ? r - 1 : r + 1;
        if (pr < 0 || pr > 7) return false;
        int pawn = side == 0 ? P : -P;
        return (f > 0 && b[pr * 8 + f - 1] == pawn) || (f < 7 && b[pr * 8 + f + 1] == pawn);
    }

    private String key() {
        return placement() + (side == 0 ? " w " : " b ") + castleStr() + " " + (epCapturePossible() ? sqName(ep) : "-");
    }

    private boolean insufficient() {
        int minors = 0, bishops = 0, lightB = 0, darkB = 0;
        for (int s = 0; s < 64; s++) {
            int t = Math.abs(b[s]);
            if (t == P || t == R || t == Q) return false;
            if (t == N || t == B) {
                minors++;
                if (t == B) { bishops++; if ((((s >> 3) + (s & 7)) & 1) == 0) darkB++; else lightB++; }
            }
        }
        if (minors <= 1) return true;
        return minors == bishops && (darkB == 0 || lightB == 0);
    }

    /** Can this color still deliver mate (used when the other side's flag falls)? */
    public boolean hasMatingMaterial(int color) {
        int minors = 0;
        for (int s = 0; s < 64; s++) {
            int pc = b[s];
            if (pc == 0 || (pc > 0) != (color == 0)) continue;
            int t = Math.abs(pc);
            if (t == P || t == R || t == Q) return true;
            if (t == N || t == B) minors++;
        }
        return minors >= 2;
    }

    /** null while the game goes on; otherwise checkmate, stalemate, insufficient, fifty or threefold. */
    public String status() {
        if (legalMoves().length == 0) return inCheckColor(side) ? "checkmate" : "stalemate";
        if (insufficient()) return "insufficient";
        if (half >= 100) return "fifty";
        String k = keys.get(keys.size() - 1);
        int cnt = 0;
        for (String s : keys) if (s.equals(k)) cnt++;
        if (cnt >= 3) return "threefold";
        return null;
    }
}
