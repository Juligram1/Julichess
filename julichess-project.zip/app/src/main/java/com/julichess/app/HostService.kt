package com.julichess.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat

/** Keeps the host server alive in the background (wake lock + foreground notification). */
class HostService : Service() {

    companion object {
        const val PORT = 8765

        fun start(ctx: Context, name: String, token: String) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, HostService::class.java).putExtra("name", name).putExtra("token", token)
            )
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, HostService::class.java))
        }
    }

    private var server: RoomServer? = null
    private var wake: PowerManager.WakeLock? = null
    private var nsdListener: NsdManager.RegistrationListener? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val name = intent?.getStringExtra("name") ?: "Julichess"
        val token = intent?.getStringExtra("token") ?: return START_NOT_STICKY

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("host", "Hosting", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "host")
            .setContentTitle("Julichess is hosting")
            .setContentText(name)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        shutdown()
        wake = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "julichess:host")
            .apply { acquire() }
        server = RoomServer(PORT, name, token, getExternalFilesDir("pgn")).also { it.start() }
        registerNsd(name)
        return START_NOT_STICKY
    }

    private fun registerNsd(name: String) {
        try {
            val info = NsdServiceInfo().apply {
                serviceName = name
                serviceType = "_julichess._tcp."
                port = PORT
            }
            val l = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(i: NsdServiceInfo) {}
                override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
                override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
            }
            nsdListener = l
            getSystemService(NsdManager::class.java)
                .registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (_: Exception) {}
    }

    private fun shutdown() {
        try { server?.stop(300) } catch (_: Exception) {}
        server = null
        nsdListener?.let {
            try { getSystemService(NsdManager::class.java).unregisterService(it) } catch (_: Exception) {}
        }
        nsdListener = null
        wake?.let { if (it.isHeld) it.release() }
        wake = null
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
